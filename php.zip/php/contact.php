<h2>Formulaire de contact</h2>
<div class="form-container">
  <form class="contact-form">
    <input type="text" id="input-name" placeholder="Nom / Pseudo">
    <input type="email" id="input-email" placeholder="Email">
    <input type="text" id="input-subject" placeholder="Sujet">
    <textarea name="message" type="text" id="input-message" placeholder="Message"></textarea>
    <input type="submit" value="Envoyer" id="input-submit">
  </form>
</div>