<?php
session_start();
include_once('../../../config.php');
include_once('./char_info.php');
include_once('./load_map.php');
loadmap(20, "minimap");
?>